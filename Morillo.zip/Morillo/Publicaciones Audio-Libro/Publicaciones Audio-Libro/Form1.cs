﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Publicaciones_Audio_Libro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rdbt_Libro_Click(object sender, EventArgs e)
        {
            txt_n_pag.Enabled = true;
            txt_tiempo.Enabled = false;
            txt_titulo.Enabled = true;
            txt_precio.Enabled = true;

            txt_n_pag.Clear();
            txt_tiempo.Clear();
            txt_titulo.Clear();
            txt_precio.Clear();
        }

        private void rdbt_audio_libro_CheckedChanged(object sender, EventArgs e)
        {
            txt_n_pag.Enabled = false;
            txt_tiempo.Enabled = true;
            txt_titulo.Enabled = true;
            txt_precio.Enabled = true;

            txt_n_pag.Clear();
            txt_tiempo.Clear();
            txt_titulo.Clear();
            txt_precio.Clear();
        }
    }
}
