﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publicaciones_Audio_Libro
{
    public class Audio
    {
        private int tiempo_minutos;
    }
}
