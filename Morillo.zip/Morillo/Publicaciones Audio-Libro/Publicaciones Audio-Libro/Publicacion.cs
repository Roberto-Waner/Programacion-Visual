﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Publicaciones_Audio_Libro
{
    abstract public class Publicacion
    {
        private string titulo;
        private float precio;
        
        public string Titulo { get => titulo; set => titulo = value; }
        public float Precio { get => precio; set => precio = value; }

        public void motrar (string @titulo, float @precio)
        {
            this.titulo = @titulo;
            this.precio = @precio;
        }
    }
}
