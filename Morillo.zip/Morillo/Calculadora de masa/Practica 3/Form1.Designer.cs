﻿namespace Practica_3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_no_estudiante = new System.Windows.Forms.TextBox();
            this.txt_matricula = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_alumno = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_edad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_libras = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_peso_kg = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_pies = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_pulgadas = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_En_metros = new System.Windows.Forms.TextBox();
            this.txt_contextura = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_imc = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgv_numero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_matricula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_alumno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_edad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_estatura = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_peso = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_imc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_contextura = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_porcentaje4 = new System.Windows.Forms.TextBox();
            this.txt_porcentaje3 = new System.Windows.Forms.TextBox();
            this.txt_porcentaje2 = new System.Windows.Forms.TextBox();
            this.txt_porcentaje1 = new System.Windows.Forms.TextBox();
            this.txt_total4 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_total3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_total2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_total1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.bt_enviar = new System.Windows.Forms.Button();
            this.bt_limpiar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero";
            // 
            // txt_no_estudiante
            // 
            this.txt_no_estudiante.Location = new System.Drawing.Point(96, 32);
            this.txt_no_estudiante.Margin = new System.Windows.Forms.Padding(2);
            this.txt_no_estudiante.Name = "txt_no_estudiante";
            this.txt_no_estudiante.Size = new System.Drawing.Size(29, 20);
            this.txt_no_estudiante.TabIndex = 1;
            // 
            // txt_matricula
            // 
            this.txt_matricula.Location = new System.Drawing.Point(96, 64);
            this.txt_matricula.Margin = new System.Windows.Forms.Padding(2);
            this.txt_matricula.Name = "txt_matricula";
            this.txt_matricula.Size = new System.Drawing.Size(78, 20);
            this.txt_matricula.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 67);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Matricula";
            // 
            // txt_alumno
            // 
            this.txt_alumno.Location = new System.Drawing.Point(20, 128);
            this.txt_alumno.Margin = new System.Windows.Forms.Padding(2);
            this.txt_alumno.Name = "txt_alumno";
            this.txt_alumno.Size = new System.Drawing.Size(212, 20);
            this.txt_alumno.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 113);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Alumno";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(18, 174);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Fecha de nacimiento";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(20, 193);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(105, 20);
            this.dateTimePicker1.TabIndex = 7;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // txt_edad
            // 
            this.txt_edad.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_edad.Enabled = false;
            this.txt_edad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_edad.Location = new System.Drawing.Point(428, 39);
            this.txt_edad.Margin = new System.Windows.Forms.Padding(2);
            this.txt_edad.Name = "txt_edad";
            this.txt_edad.Size = new System.Drawing.Size(107, 21);
            this.txt_edad.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(322, 41);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Edad";
            // 
            // txt_libras
            // 
            this.txt_libras.Location = new System.Drawing.Point(110, 227);
            this.txt_libras.Margin = new System.Windows.Forms.Padding(2);
            this.txt_libras.Name = "txt_libras";
            this.txt_libras.Size = new System.Drawing.Size(56, 20);
            this.txt_libras.TabIndex = 11;
            this.txt_libras.Validated += new System.EventHandler(this.txt_libras_Validated);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(18, 228);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Libras";
            // 
            // txt_peso_kg
            // 
            this.txt_peso_kg.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_peso_kg.Enabled = false;
            this.txt_peso_kg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_peso_kg.Location = new System.Drawing.Point(428, 79);
            this.txt_peso_kg.Margin = new System.Windows.Forms.Padding(2);
            this.txt_peso_kg.Name = "txt_peso_kg";
            this.txt_peso_kg.Size = new System.Drawing.Size(107, 21);
            this.txt_peso_kg.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(322, 81);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Peso a KG";
            // 
            // txt_pies
            // 
            this.txt_pies.Location = new System.Drawing.Point(110, 255);
            this.txt_pies.Margin = new System.Windows.Forms.Padding(2);
            this.txt_pies.Name = "txt_pies";
            this.txt_pies.Size = new System.Drawing.Size(56, 20);
            this.txt_pies.TabIndex = 15;
            this.txt_pies.Validated += new System.EventHandler(this.txt_pies_Validated);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 257);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Pies";
            // 
            // txt_pulgadas
            // 
            this.txt_pulgadas.Location = new System.Drawing.Point(110, 288);
            this.txt_pulgadas.Margin = new System.Windows.Forms.Padding(2);
            this.txt_pulgadas.Name = "txt_pulgadas";
            this.txt_pulgadas.Size = new System.Drawing.Size(56, 20);
            this.txt_pulgadas.TabIndex = 17;
            this.txt_pulgadas.Validated += new System.EventHandler(this.txt_pulgadas_Validated);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 289);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 17);
            this.label9.TabIndex = 16;
            this.label9.Text = "Pulgadas";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.txt_pulgadas);
            this.panel1.Controls.Add(this.txt_alumno);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txt_pies);
            this.panel1.Controls.Add(this.txt_no_estudiante);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txt_matricula);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txt_libras);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Location = new System.Drawing.Point(9, 10);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(248, 324);
            this.panel1.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Left;
            this.label10.Location = new System.Drawing.Point(0, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Ingrese sus datos aqui";
            // 
            // txt_En_metros
            // 
            this.txt_En_metros.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_En_metros.Enabled = false;
            this.txt_En_metros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_En_metros.Location = new System.Drawing.Point(428, 124);
            this.txt_En_metros.Margin = new System.Windows.Forms.Padding(2);
            this.txt_En_metros.Name = "txt_En_metros";
            this.txt_En_metros.Size = new System.Drawing.Size(107, 21);
            this.txt_En_metros.TabIndex = 20;
            // 
            // txt_contextura
            // 
            this.txt_contextura.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_contextura.Enabled = false;
            this.txt_contextura.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_contextura.Location = new System.Drawing.Point(428, 165);
            this.txt_contextura.Margin = new System.Windows.Forms.Padding(2);
            this.txt_contextura.Name = "txt_contextura";
            this.txt_contextura.Size = new System.Drawing.Size(107, 21);
            this.txt_contextura.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(322, 167);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 17);
            this.label12.TabIndex = 21;
            this.label12.Text = "Contextura";
            // 
            // txt_imc
            // 
            this.txt_imc.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_imc.Enabled = false;
            this.txt_imc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_imc.Location = new System.Drawing.Point(428, 204);
            this.txt_imc.Margin = new System.Windows.Forms.Padding(2);
            this.txt_imc.Name = "txt_imc";
            this.txt_imc.Size = new System.Drawing.Size(107, 21);
            this.txt_imc.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(322, 206);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 17);
            this.label13.TabIndex = 23;
            this.label13.Text = "IMC";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(322, 120);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 34);
            this.label11.TabIndex = 25;
            this.label11.Text = "Estatura en \r\nmetros";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgv_numero,
            this.dgv_matricula,
            this.dgv_alumno,
            this.dgv_edad,
            this.dgv_estatura,
            this.dgv_peso,
            this.dgv_imc,
            this.dgv_contextura});
            this.dataGridView1.Location = new System.Drawing.Point(9, 352);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(920, 292);
            this.dataGridView1.TabIndex = 26;
            // 
            // dgv_numero
            // 
            this.dgv_numero.HeaderText = "No. Alumno";
            this.dgv_numero.MinimumWidth = 6;
            this.dgv_numero.Name = "dgv_numero";
            this.dgv_numero.ReadOnly = true;
            // 
            // dgv_matricula
            // 
            this.dgv_matricula.HeaderText = "Matricula";
            this.dgv_matricula.MinimumWidth = 6;
            this.dgv_matricula.Name = "dgv_matricula";
            this.dgv_matricula.ReadOnly = true;
            // 
            // dgv_alumno
            // 
            this.dgv_alumno.HeaderText = "Alumno";
            this.dgv_alumno.MinimumWidth = 6;
            this.dgv_alumno.Name = "dgv_alumno";
            this.dgv_alumno.ReadOnly = true;
            // 
            // dgv_edad
            // 
            this.dgv_edad.HeaderText = "Edad";
            this.dgv_edad.MinimumWidth = 6;
            this.dgv_edad.Name = "dgv_edad";
            this.dgv_edad.ReadOnly = true;
            // 
            // dgv_estatura
            // 
            this.dgv_estatura.HeaderText = "Estatura";
            this.dgv_estatura.MinimumWidth = 6;
            this.dgv_estatura.Name = "dgv_estatura";
            this.dgv_estatura.ReadOnly = true;
            // 
            // dgv_peso
            // 
            this.dgv_peso.HeaderText = "Peso";
            this.dgv_peso.MinimumWidth = 6;
            this.dgv_peso.Name = "dgv_peso";
            this.dgv_peso.ReadOnly = true;
            // 
            // dgv_imc
            // 
            this.dgv_imc.HeaderText = "IMC";
            this.dgv_imc.MinimumWidth = 6;
            this.dgv_imc.Name = "dgv_imc";
            this.dgv_imc.ReadOnly = true;
            // 
            // dgv_contextura
            // 
            this.dgv_contextura.HeaderText = "Contextura";
            this.dgv_contextura.MinimumWidth = 6;
            this.dgv_contextura.Name = "dgv_contextura";
            this.dgv_contextura.ReadOnly = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_porcentaje4);
            this.groupBox1.Controls.Add(this.txt_porcentaje3);
            this.groupBox1.Controls.Add(this.txt_porcentaje2);
            this.groupBox1.Controls.Add(this.txt_porcentaje1);
            this.groupBox1.Controls.Add(this.txt_total4);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txt_total3);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txt_total2);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txt_total1);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Location = new System.Drawing.Point(601, 19);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(328, 203);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Estadisticas";
            // 
            // txt_porcentaje4
            // 
            this.txt_porcentaje4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_porcentaje4.Enabled = false;
            this.txt_porcentaje4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_porcentaje4.Location = new System.Drawing.Point(239, 168);
            this.txt_porcentaje4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_porcentaje4.Name = "txt_porcentaje4";
            this.txt_porcentaje4.Size = new System.Drawing.Size(51, 21);
            this.txt_porcentaje4.TabIndex = 35;
            // 
            // txt_porcentaje3
            // 
            this.txt_porcentaje3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_porcentaje3.Enabled = false;
            this.txt_porcentaje3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_porcentaje3.Location = new System.Drawing.Point(239, 128);
            this.txt_porcentaje3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_porcentaje3.Name = "txt_porcentaje3";
            this.txt_porcentaje3.Size = new System.Drawing.Size(51, 21);
            this.txt_porcentaje3.TabIndex = 34;
            // 
            // txt_porcentaje2
            // 
            this.txt_porcentaje2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_porcentaje2.Enabled = false;
            this.txt_porcentaje2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_porcentaje2.Location = new System.Drawing.Point(239, 87);
            this.txt_porcentaje2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_porcentaje2.Name = "txt_porcentaje2";
            this.txt_porcentaje2.Size = new System.Drawing.Size(51, 21);
            this.txt_porcentaje2.TabIndex = 33;
            // 
            // txt_porcentaje1
            // 
            this.txt_porcentaje1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_porcentaje1.Enabled = false;
            this.txt_porcentaje1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_porcentaje1.Location = new System.Drawing.Point(239, 50);
            this.txt_porcentaje1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_porcentaje1.Name = "txt_porcentaje1";
            this.txt_porcentaje1.Size = new System.Drawing.Size(51, 21);
            this.txt_porcentaje1.TabIndex = 32;
            // 
            // txt_total4
            // 
            this.txt_total4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_total4.Enabled = false;
            this.txt_total4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total4.Location = new System.Drawing.Point(134, 168);
            this.txt_total4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_total4.Name = "txt_total4";
            this.txt_total4.Size = new System.Drawing.Size(59, 21);
            this.txt_total4.TabIndex = 31;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(18, 169);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 15);
            this.label20.TabIndex = 31;
            this.label20.Text = "Obesidad";
            // 
            // txt_total3
            // 
            this.txt_total3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_total3.Enabled = false;
            this.txt_total3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total3.Location = new System.Drawing.Point(134, 128);
            this.txt_total3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_total3.Name = "txt_total3";
            this.txt_total3.Size = new System.Drawing.Size(59, 21);
            this.txt_total3.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(18, 53);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 15);
            this.label17.TabIndex = 30;
            this.label17.Text = "Normal";
            // 
            // txt_total2
            // 
            this.txt_total2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_total2.Enabled = false;
            this.txt_total2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total2.Location = new System.Drawing.Point(134, 87);
            this.txt_total2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_total2.Name = "txt_total2";
            this.txt_total2.Size = new System.Drawing.Size(59, 21);
            this.txt_total2.TabIndex = 29;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(18, 128);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 15);
            this.label18.TabIndex = 29;
            this.label18.Text = "Sobre Peso";
            // 
            // txt_total1
            // 
            this.txt_total1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txt_total1.Enabled = false;
            this.txt_total1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total1.Location = new System.Drawing.Point(134, 50);
            this.txt_total1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_total1.Name = "txt_total1";
            this.txt_total1.Size = new System.Drawing.Size(59, 21);
            this.txt_total1.TabIndex = 28;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(225, 22);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(86, 17);
            this.label15.TabIndex = 29;
            this.label15.Text = "Porcentaje";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(18, 90);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 15);
            this.label19.TabIndex = 28;
            this.label19.Text = "Delgadez";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(18, 22);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 17);
            this.label14.TabIndex = 30;
            this.label14.Text = "Contexturas";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(131, 22);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 17);
            this.label16.TabIndex = 28;
            this.label16.Text = "Totales";
            // 
            // bt_enviar
            // 
            this.bt_enviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_enviar.Location = new System.Drawing.Point(601, 279);
            this.bt_enviar.Margin = new System.Windows.Forms.Padding(2);
            this.bt_enviar.Name = "bt_enviar";
            this.bt_enviar.Size = new System.Drawing.Size(165, 49);
            this.bt_enviar.TabIndex = 28;
            this.bt_enviar.Text = "Enviar";
            this.bt_enviar.UseVisualStyleBackColor = true;
            this.bt_enviar.Click += new System.EventHandler(this.bt_enviar_Click);
            // 
            // bt_limpiar
            // 
            this.bt_limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_limpiar.Location = new System.Drawing.Point(770, 279);
            this.bt_limpiar.Margin = new System.Windows.Forms.Padding(2);
            this.bt_limpiar.Name = "bt_limpiar";
            this.bt_limpiar.Size = new System.Drawing.Size(159, 49);
            this.bt_limpiar.TabIndex = 29;
            this.bt_limpiar.Text = "Limpiar";
            this.bt_limpiar.UseVisualStyleBackColor = true;
            this.bt_limpiar.Click += new System.EventHandler(this.bt_limpiar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(937, 655);
            this.Controls.Add(this.bt_limpiar);
            this.Controls.Add(this.bt_enviar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_imc);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_contextura);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_En_metros);
            this.Controls.Add(this.txt_peso_kg);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_edad);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_no_estudiante;
        private System.Windows.Forms.TextBox txt_matricula;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_alumno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txt_edad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_libras;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_peso_kg;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_pies;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_pulgadas;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_En_metros;
        private System.Windows.Forms.TextBox txt_contextura;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_imc;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txt_total4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_total3;
        private System.Windows.Forms.TextBox txt_total2;
        private System.Windows.Forms.TextBox txt_total1;
        private System.Windows.Forms.TextBox txt_porcentaje4;
        private System.Windows.Forms.TextBox txt_porcentaje3;
        private System.Windows.Forms.TextBox txt_porcentaje2;
        private System.Windows.Forms.TextBox txt_porcentaje1;
        private System.Windows.Forms.Button bt_enviar;
        private System.Windows.Forms.Button bt_limpiar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_numero;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_matricula;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_alumno;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_edad;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_estatura;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_peso;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_imc;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgv_contextura;
    }
}

